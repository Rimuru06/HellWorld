# HellWorld
This game was made by Thiago Aragão and Leonardo Soares, two students of Computer Science in the Fluminense Federal University (UFF), as a game project for the subject Lab of Game Programming.

This game was made entirely in Pyhton and using the frameworks and libraries PPlay (http://www2.ic.uff.br/pplay/en) and Pygames (https://www.pygame.org).